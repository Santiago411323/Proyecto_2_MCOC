"""Verificaciones reproducibles del motor del SHA dcc5890, sin datos de obra."""
from pathlib import Path
import sys,json,csv,time,os
BASE=Path(__file__).parent;REPO=Path(os.environ.get('THERMA_REPO',BASE/'fuentes/Proyecto_2_MCOC-dcc589064ff6fd899a4ab7aa8be224c267903cf3'))
sys.path.insert(0,str(REPO))
import numpy as np
from casos_verificacion import sinusoidal
from termico_cartesiano import TermicoCartesiano
OUT=Path(os.environ.get('F01_OUT',BASE/'evidencia_nueva'))/'benchmarks';OUT.mkdir(exist_ok=True,parents=True)
rows=[]
for dim in (1,2,3):
    for n in (8,16,32):
        t=time.perf_counter();m,r,exact,dt=sinusoidal(dim,n)
        rows.append(dict(case=f'sinusoidal_{dim}d',n=n,dt_s=dt,end_s=.03,error_Linf_K=float(np.abs(r['T']-exact).max()),runtime_s=time.perf_counter()-t))
for n in (8,16,32):
    mu=.7;a=.5;h=mu*np.tan(mu)/a
    R=dict(tipo='robin',h_W_m2K=h,temperatura_C=20.)
    m=TermicoCartesiano((n,),(1.,),k=1.,rho=1.,cp=1.,bordes={'x-':R,'x+':R})
    initial=20+10*np.cos(mu*(m.coordenadas[0]-a)/a);dt=.7*m.dt_max
    t=time.perf_counter();r=m.resolver(initial,.1,dt)
    exact=20+(initial-20)*np.exp(-(mu/a)**2*.1)
    rows.append(dict(case='robin_1d',n=n,dt_s=dt,end_s=.1,error_Linf_K=float(np.abs(r['T']-exact).max()),runtime_s=time.perf_counter()-t))
with (OUT/'errores.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert rows[2]['error_Linf_K']<rows[1]['error_Linf_K']<rows[0]['error_Linf_K']
assert rows[-1]['error_Linf_K']<.003
(OUT/'parametros.json').write_text(json.dumps(dict(source_commit='dcc589064ff6fd899a4ab7aa8be224c267903cf3',sinusoidal=dict(L_m=1,alpha_m2s=1,rho=1,cp=1,T0_C=20,amplitude_K=10,duration_s=.03,dt_fraction=.7),robin=dict(mu=.7,a_m=.5,h_W_m2K=float(h),k=1,rho=1,cp=1,Tinf_C=20,amplitude_K=10,duration_s=.1,other_directions='adiabatic'),scope='Casos matemáticos, no calibración ni validación de la fundación'),indent=2)+'\n')
print(json.dumps(rows,indent=2))

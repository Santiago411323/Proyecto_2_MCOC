"""Reproduce, sin cambiar física, las 24 combinaciones del ejecutor dcc5890."""
from pathlib import Path
import importlib.util,json,csv,time,sys,platform,os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone

BASE=Path(__file__).parent
REPO=Path(os.environ.get('THERMA_REPO',BASE/'fuentes/Proyecto_2_MCOC-dcc589064ff6fd899a4ab7aa8be224c267903cf3'))
OUT=Path(os.environ.get('F01_OUT',BASE/'evidencia_nueva'))/'t8_24';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(REPO))
start=time.perf_counter()
spec=importlib.util.spec_from_file_location('engine_t8',REPO/'docs/defensa_grupo9/escenarios_T8/calcular.py')
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
setup=time.perf_counter()-start
import numpy as np
def one(case):
    w,s=case;p=OUT/f'{engine.CLIMATES[w]}_{engine.NAMES[s]}.json'
    if p.exists():return json.loads(p.read_text())
    t=time.perf_counter();r=engine.simulate(case,output_dir=None)
    r.update(runtime_s=time.perf_counter()-t,source_commit='dcc589064ff6fd899a4ab7aa8be224c267903cf3',execution_date_utc=datetime.now(timezone.utc).date().isoformat(),numerical_equivalence_to_original=True)
    p.write_text(json.dumps(r,indent=2)+'\n');print('GUARDADO',p.name,'segundos',round(r['runtime_s'],2),flush=True)
    return r
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(one,[(w,s) for w in range(3) for s in range(8)]))
with (OUT/'resultados.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
import importlib.metadata
summary=dict(source_commit='dcc589064ff6fd899a4ab7aa8be224c267903cf3',setup_s=setup,wall_s=time.perf_counter()-start,sum_case_runtime_s=sum(r['runtime_s'] for r in results),workers=4,python=sys.version,numpy=np.__version__,numba=importlib.metadata.version('numba'),llvmlite=importlib.metadata.version('llvmlite'),platform=platform.platform(),cpu=platform.processor(),case_count=len(results),all_horizons_captured=all(r['horizon_captured'] for r in results),max_T=max(r['Tmax_C'] for r in results),max_Delta=max(r['Delta_C'] for r in results),max_common_reference_error=max(r.get('reference_max_error_C',0) for r in results))
(OUT/'reproduccion.json').write_text(json.dumps(summary,indent=2)+'\n')
np.save(OUT.parent/'mask96.npy',engine.ids)
print('FINAL',json.dumps(summary),flush=True)

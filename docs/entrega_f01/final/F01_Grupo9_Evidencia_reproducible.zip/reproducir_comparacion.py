"""Métricas y localizaciones M4_SS de cinco planes archivados, misma física dcc5890.
Núcleos de avance y reconstrucción copiados sin cambiar ecuaciones del ejecutor T8.
La equivalencia con Tmax y Delta archivados se exige antes de publicar una fila.
"""
from pathlib import Path
import sys,json,time,csv,os
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from numba import njit
BASE=Path(__file__).parent;REPO=Path(os.environ.get('THERMA_REPO',BASE/'fuentes/Proyecto_2_MCOC-dcc589064ff6fd899a4ab7aa8be224c267903cf3'));sys.path.insert(0,str(REPO))
from therma.ejecutar import validar
from therma.comparacion_f02 import op_config
from therma.fuente_tabulada import FuenteTabulada
from therma.meteorologia import ForzanteAire
from therma.moldaje import resistencia_extra
from therma.suelo import validar_entorno
from therma.superficies_ifc import cargar_superficies
from therma.reconstruccion_s25 import Reconstruccion
from termico_cartesiano import TermicoCartesiano
OUT=Path(os.environ.get('F01_OUT',BASE/'evidencia_nueva'))/'comparacion_m4';OUT.mkdir(exist_ok=True,parents=True)
CAT=json.loads((REPO/'docs/cierre_f02/evidencia/catalogo_congelado.json').read_text())
DURATION=42*86400
@njit(nogil=True)
def march(old,new,idx,neighbors,labels,axis_g,ga,gs,air,ground,h,source):
    hot=-1e20;hotidx=-1
    for j in range(idx.size):
        i=idx[j];v=old[i];power=ga[j]*(air-v)+gs[j]*(ground-v)+source[labels[j]]
        for a in range(3):power+=axis_g[a]*((old[neighbors[j,a*2]]-v)+(old[neighbors[j,a*2+1]]-v))
        x=v+h*power;new[i]=x
        if x>hot:hot=x;hotidx=i
    return hot,hotidx
@njit(nogil=True)
def lowest(T,indices,weights,offset):
    cold=1e30;pt=-1
    for j in range(len(offset)-1):
        v=0.
        for k in range(offset[j],offset[j+1]):v+=T[indices[k]]*weights[k]
        if v<cold:cold=v;pt=j
    return cold,pt

def one(pid):
    path=OUT/(pid+'.json')
    if path.exists():return json.loads(path.read_text())
    st=time.perf_counter();plan=next(p for p in CAT['plans'] if p['id']==pid)
    cfg=op_config(CAT,plan,'fv_M4_SS',[96,96,54],days=42,dt=1200)
    p=validar(cfg);shape=tuple(p['n']);dx=np.array(p['L'])/shape;origin=np.array(p['origin'])
    ids=np.ascontiguousarray(np.array(p['mask']).reshape(shape[::-1]).T)
    pours=p['construction']['pours'];starts=np.array([o['start_h']*3600 for o in pours]);placement={o['id']:o['placement_C'] for o in pours}
    soil=validar_entorno(p);gp=REPO/'modelo_e02.ifc';surf=cargar_superficies(str(gp),gp.stat().st_mtime_ns,p['s25']['surface_spacing_m'])
    stages=[]
    for stage in range(1,4):
        active=(ids>0)&(ids<=stage);exterior={}
        for n,b in enumerate(p['faces']):exterior['xyz'[n//2]+'-+'[n%2]]=dict(tipo='robin',h_W_m2K=b['h'],R_m2K_W=b['R']+resistencia_extra(p,n,0),temperatura_C=0.)
        model=TermicoCartesiano(shape,p['L'],p['k'],p['rho'],p['cp'],soil.bordes(active,exterior),active);assert p['dt']<=model.dt_max
        gs,_=soil.terminos_diagnosticos(model);ga=model.G_borde-gs;cap=p['rho']*p['cp']*model.volumen
        axis_g=np.array([model.volumen/d**2*p['k']/cap for d in dx]);ix=np.flatnonzero(active.ravel()).astype(np.int32);nb=np.repeat(ix[:,None],6,axis=1)
        for a,(lo,hi,G) in enumerate(model.pares):
            pair=np.argwhere(G>0);left=np.ravel_multi_index(pair.T,shape);pair[:,a]+=1;right=np.ravel_multi_index(pair.T,shape)
            nb[np.searchsorted(ix,left),2*a+1]=right;nb[np.searchsorted(ix,right),2*a]=left
        sample=surf.at(tuple(range(1,stage+1)));rec=Reconstruccion(sample['points'],active,p['origin'],dx,cell_ids=ids,point_ids=sample['point_owner'],allow_partial=True);assert rec.supported.all()
        stages.append((ix,nb,ids.ravel()[ix],axis_g,ga.ravel()[ix]/cap,gs.ravel()[ix]/cap,rec.indices.astype(np.int32),rec.weights,np.r_[rec.starts,len(rec.weights)],sample['points']))
    weather=ForzanteAire(cfg['weather'],DURATION)
    targets=set(np.linspace(0,DURATION,p['frames']))|set(starts)|{float(t-1) for t in starts[1:]};times=[0.]
    for target in sorted(targets)[1:]:
        while times[-1]<target-1e-9:
            t=times[-1];times.append(min(t+p['dt'],target,weather.siguiente(t)))
    times=np.array(times);src=FuenteTabulada(cfg['construction']['curve'],p['rho'],p['cp']);rates=np.zeros((len(times)-1,4))
    for layer,activation in enumerate(starts,1):
        e=np.array([src.energia_volumetrica(max(0,t-activation)) for t in times]);rates[:,layer]=np.diff(e)/np.diff(times)/(p['rho']*p['cp'])
    T=np.zeros(ids.size);tmp=T.copy();T[stages[0][0]]=placement[1];stage=0;peaks=[-1e9,-1e9];location={};hist=[]
    for j,h in enumerate(np.diff(times)):
        ix,nb,labels,g,ga,gs,indices,weights,offset,xyz=stages[stage]
        hot,hidx=march(T,tmp,ix,nb,labels,g,ga,gs,weather.temperatura(times[j]),soil.temperature_C,h,rates[j]);T,tmp=tmp,T
        if stage<2 and times[j+1]>=starts[stage+1]-1e-9:
            stage+=1;fresh=ids.ravel()==stage+1;T[fresh]=placement[stage+1]
            if hot<placement[stage+1]:hot=float(placement[stage+1]);hidx=int(np.flatnonzero(fresh)[0])
            indices,weights,offset,xyz=stages[stage][6:]
        cold,cidx=lowest(T,indices,weights,offset);pair=hot-cold
        for index,value,prefix in [(0,hot,'T'),(1,pair,'D')]:
            if value>peaks[index]:
                peaks[index]=value;location[prefix+'_time_h']=times[j+1]/3600
                location[prefix+'_hot_xyz_m']=(origin+(np.array(np.unravel_index(hidx,shape))+.5)*dx).tolist()
                if index:location['D_S25_xyz_m']=xyz[cidx].tolist()
        hist.append((times[j+1]/3600,hot,cold,pair))
    if pid=='t12_eps100_base1.0':refpath=REPO/'docs/hielo_f02/convergencia/T12_96x96x54_dt1200_fv_M4_SS.json'
    else:refpath=REPO/f'docs/malla_comun/corridas/{pid}_96x96x54_dt1200_fv_M4_SS.json'
    ref=json.loads(refpath.read_text());err=max(abs(peaks[0]-ref['Tmax_C']),abs(peaks[1]-ref['Delta_estimate_C']));assert err<1e-6,(pid,peaks,ref['Tmax_C'],ref['Delta_estimate_C'],err)
    hist=np.array(hist);r=dict(plan_id=pid,D_h=plan['D_h'],Tmax_C=peaks[0],Delta_C=peaks[1],T14_C=float(hist[hist[:,0]<=336,1].max()),D14_C=float(hist[hist[:,0]<=336,3].max()),reference_max_error_C=err,source='M4_SS',climate='OM16',runtime_s=time.perf_counter()-st,source_commit='dcc589064ff6fd899a4ab7aa8be224c267903cf3',**location)
    path.write_text(json.dumps(r,indent=2)+'\n');np.savetxt(OUT/(pid+'_historia.csv'),hist,delimiter=',',header='time_h,Tmax_C,Tmin_S25_C,Delta_C',comments='')
    print(pid,peaks,'err',err,'s',r['runtime_s'],flush=True);return r

if __name__=='__main__':
    st=time.perf_counter()
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(one,['t12_eps100_base1.0','continua','rapido','propuesto','lento']))
    with (OUT/'resultados.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
    (OUT/'reproduccion.json').write_text(json.dumps(dict(wall_s=time.perf_counter()-st,count=len(results),workers=2,max_reference_error_C=max(r['reference_max_error_C'] for r in results)),indent=2)+'\n')

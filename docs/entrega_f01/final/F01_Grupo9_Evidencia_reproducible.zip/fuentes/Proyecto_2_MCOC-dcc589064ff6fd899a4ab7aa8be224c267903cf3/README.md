# Proyecto 2 — G9: Punta Arenas / Tehuel Aike

**Actualización de fuentes, 16-11-2026:** el usuario retiró por incorrecta la
fuente PINN anterior. `data/hydration/source_terms.txt` contiene ahora el archivo
FV/Tikhonov corregido, idéntico al alias `source_terms_fv_tikhonov.txt` del último
pull. [Procedencia y estado](data/hydration/README.md). La [entrega E12 anterior](docs/e12/README.md)
es histórica y no vigente; sus resultados no corresponden a estos datos.

## E12 — Caso determinista de 14 días

`ejecutar_e12.py` usa una sola fuente del archivo entregado (`M1_SS`, en W/m³),
con cola constante explícita, forecast archivado, vertidas, suelo y moldaje.
La entrega y las limitaciones del diagnóstico están en [E12](docs/e12/ENTREGA.md).

```powershell
.\.venv\Scripts\python.exe ejecutar_e12.py --salida resultados/e12_nueva
.\.venv\Scripts\python.exe ver_resultados_3d.py docs/e12/evidencia/vtk
```

En THERMA Lab, **Cargar ajustes** permite abrir `docs/e12/evidencia/config.json`;
conserva la fuente tabulada y deshabilita los parámetros exponenciales ajenos a ella.
El diagnóstico reconstruido de superficie y su máximo se calculan con el script E12;
el par núcleo/exterior del visor web sigue siendo un par de centros de voxel.

## E10 — Clima trazable y retiro de moldaje

Ver [guía de E10](docs/E10_ENTORNO_Y_CLIMA.md). `clima.py descargar` guarda forecasts
sin sobrescribir; `demo_e10.py` conecta aire horario, suelo efectivo y moldaje al
motor constructivo. El panel permite cargar `docs/e10/weather_para_panel.json`
en **05B Forecast trazable**. El retiro global se configura en **03B Moldaje**.
Sin extrapolación: si falta cobertura se rechaza la corrida. h constante;
viento y radiación no conectados. La guía incluye comandos y limitaciones.

Avance inicial para E01/E02: IFC → Python, voxelización G04, difusión térmica 1D y tests.
Integrantes: pendiente de completar. Punto meteorológico docente: latitud
**-52.821770**, longitud **-70.896850** (ver `sitio.json`).

## Construcción por vertidas · Fase 4

Activación física por horarios, hidratación adiabática didáctica por edad,
conectividad y fronteras reconstruidas con el solver oficial. En el panel elegir
**Fundación · secuencia constructiva didáctica**. Ver `docs/FASE4_CONSTRUCCION.md`.
Demo CLI: `.\.venv\Scripts\python.exe demo_construccion.py --malla 0`.

## Thermal Intelligence · Fase 3

Sensores persistentes, investigación de hotspots, archivo local de escenarios y
comparación A/B con campo B−A. Ver `docs/FASE3_THERMAL_INTELLIGENCE.md` para uso,
alineación temporal, compatibilidad de grillas y límites de interpretación.

## Panel interactivo de ejercicios

**THERMA Fase 2: visor 3D Three.js local + solver Python real.** Iniciar:

```powershell
.\.venv\Scripts\python.exe construir_panel.py
.\.venv\Scripts\python.exe servidor_therma.py
```

Abrir `http://127.0.0.1:8767/panel_termico.html`. Ver
`docs/FASE1_IMPLEMENTACION.md` para contrato, estados, reproducción 3D y demo.
El servidor estático anterior (8766) no ejecuta Python.
Ver `docs/FASE2_VISOR_3D.md` para cámara, cortes X-Ray, selección, timeline y validaciones.

El panel permite cambiar geometría,
malla, material, condiciones de borde por cara, fuente, dt y calibración de
Qmax; muestra campos animados, curvas, comparaciones y exporta CSV/PNG/JSON.
El visor WebGL utiliza recursos locales incluidos en el repo y requiere el servidor.
No necesita internet. Conserva el laboratorio de verificación y el dominio de fundación voxelizado
desde el IFC y bloques rectangulares de prueba. Las tres capas de la
fundación están presentes desde t=0; clima e hidratación son aún de ensayo.
Ver `docs/PANEL_INTERACTIVO.md` para uso, hipótesis y verificación con Python.

## Semana 2 — solver general 1D/2D/3D

El motor nuevo `termico_cartesiano.py` usa balances de energía por celdas con
Dirichlet, Neumann, Robin, fuente volumétrica y materiales heterogéneos.
No introduce hidratación ni clima real. Los casos 2D/3D son verificaciones
matemáticas, no temperaturas de la fundación. Ver `docs/SEMANA2_SOLVER_GENERAL.md`.

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_cartesiano.py -v
.\.venv\Scripts\python.exe demo_semana2.py
```

Abrir `resultados/semana2`: `sinusoidal_2d.png`, `sinusoidal_3d.png`,
`balances_y_bordes.png`, `dos_materiales.png`, `convergencia_1d_2d_3d.png`.
Los campos completos se guardan como NPZ. El BIM del caso base sigue en
`modelo_e02.ifc` y se inspecciona desde Bonsai.

Para cambiar parámetros en vivo según la pauta de esta semana:

```powershell
.\.venv\Scripts\python.exe verificar_parametros.py --dim 3 --longitudes 2 1 0.6 --celdas 20 16 12 --alpha 0.2 --t0 12 --amplitud 7 --duracion 0.08 --salida resultados/pauta_3d
.\.venv\Scripts\python.exe verificar_parametros.py --caso fuente --dim 3 --q0 24 --rho 2 --cp 3 --duracion 0.1 --salida resultados/pauta_fuente
```

Ver `docs/PAUTA_PARAMETROS_SEMANA2.md` para las fórmulas exactas, unidades y
efectos esperados al variar cada parámetro. El caso fuente es adiabático en todas
las caras; no modela hidratación todavía.

## Instalación en Windows

Requisitos: Python 3.12, Git y Blender 4.5 con Bonsai 0.9.0 para editar IFC.
Abrir esta carpeta en VS Code y ejecutar en PowerShell:

```powershell
& "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
```

Se incluyen rangos de versiones en `requirements.txt` y las versiones verificadas
en `requirements-lock.txt`. Para reproducir el entorno validado, instalar este último.
No hace falta activar el entorno: los comandos usan directamente su ejecutable.

## Demo IFC (round-trip)

`modelo_e02.ifc` contiene una fundación continua interpretada de la diapositiva 4:
base octogonal de 18 × 18 m, transición inclinada y parte superior cilíndrica de
diámetro 7 m, con altura total 3,30 m. Los tres objetos IfcFooting corresponden a
capas contiguas de 1,10 m (Vertida_01/02/03), con GlobalId distintos.
La transición y el plan de capas son provisionales y requieren validación docente;
ver `docs/GEOMETRIA_FUNDACION.md` y parámetros en `geometria_fundacion.json`.

```powershell
.\.venv\Scripts\python.exe ver_fundacion.py
```

Genera `resultados/fundacion/fundacion_3d_actualizada.png` y `planta_corte.png`.
`crear_fundacion.py` reconstruye el IFC con esos parámetros (sobrescribe el archivo;
no ejecutar si se quieren conservar ediciones manuales). `preparar_ifc_demo.py`
queda como generador histórico del ejercicio de cubos, no de la fundación actual.

1. Abrir `modelo_e02.ifc` con **File → Open IFC Project** en Bonsai.
2. Guardar el estado inicial desde la terminal:

```powershell
.\.venv\Scripts\python.exe leer_ifc.py modelo_e02.ifc --guardar resultados/antes.json
```

3. En Bonsai seleccionar Vertida_01 y editar su atributo IFC **Name** a
   Vertida_01_modificada. Confirmar la edición del atributo y guardar con
   **File → Save IFC Project**. No basta cambiar una etiqueta de Blender
   que no se sincronice con IFC, ni guardar solamente un archivo .blend.
4. Leer otra vez el archivo desde disco:

```powershell
.\.venv\Scripts\python.exe leer_ifc.py modelo_e02.ifc --comparar resultados/antes.json
```

Debe mostrar un cambio de nombre con el mismo GlobalId. El lector compara
nombre, clase, Pset_HormigonMasivo y métricas geométricas (dimensiones, posición,
volumen y área). Puede detectar agrandar la base; no demuestra equivalencia total
de dos formas que compartan todas esas métricas. Restaurar el nombre original
y guardar antes de volver a ejecutar la batería completa de tests.
La prueba automatizada modifica una copia temporal; el round-trip interactivo
en Bonsai debe ensayarse por separado.

## Solver 1D

### Gráficos de esta etapa sobre la altura de 3,30 m

```powershell
.\.venv\Scripts\python.exe graficos_fundacion_1d.py
```

Abrir `resultados/fundacion_1d/01_perfiles_altura.png` y
`02_centro_y_extremos.png`. Compara Dirichlet, Neumann aislado y Robin a lo
largo de una columna idealizada de 3,30 m. Es una comparación de condiciones
de borde, no una predicción de la fundación real: condición inicial sinusoidal
impuesta (extremos 20 °C, centro 60 °C), sin hidratación, material uniforme y
sin pérdidas laterales. El período de 14 días es un horizonte de demostración.
La altura proviene del JSON geométrico; no se leen secciones ni áreas del IFC
para el cálculo térmico 1D. Las condiciones se documentan en `docs/GRAFICOS_1D.md`.

El motor nuevo está en `difusion_1d_bordes.py`; permite elegir cada extremo
independientemente y agrega una fuente uniforme opcional. El script original
`solver_1d.py` se conserva como benchmark de un metro con Dirichlet:

```powershell
.\.venv\Scripts\python.exe solver_1d.py
.\.venv\Scripts\python.exe solver_1d.py --dx 0.025 --dt 150 --salida resultados/fino
.\.venv\Scripts\python.exe solver_1d.py --dx 0.025 --dt 600
```

El tercer comando debe rechazar la configuración por inestabilidad.
Las corridas válidas generan perfil.csv, centro.csv, temperaturas.png y resumen.txt.

### Física y discretización

Se resuelve rho*cp*dT/dt = k*d²T/dx² en una barra de longitud L=1 m.
No hay fuente de calor. Los dos extremos tienen Dirichlet T=20 °C.
Condición inicial: T(x,0)=20+40*sin(pi*x/L) °C.
Solución exacta: T(x,t)=20+40*exp(-alpha*pi²*t/L²)*sin(pi*x/L).

Valores ilustrativos, NO calibrados para el hormigón del proyecto:
k=2 W/(m K), rho=2400 kg/m³, cp=900 J/(kg K), alpha=k/(rho*cp).
Se usan diferencias centradas en espacio y Euler explícito en tiempo:

T_i^(n+1) = T_i^n + Fo*(T_(i+1)^n - 2*T_i^n + T_(i-1)^n).

Fo=alpha*dt/dx² debe ser <=0.5 para este esquema y estos bordes.
La actualización usa un arreglo nuevo para no mezclar instantes.
Al reducir dx a la mitad, dt debe reducirse al menos a un cuarto para
mantener el mismo Fo. La última iteración acorta dt si hace falta para
alcanzar exactamente la duración. La precisión se evalúa con la solución exacta.
En una grilla gruesa, la temperatura del centro se interpola linealmente.

El solver original es independiente de Blender y del IFC en esta etapa. Aún no incorpora
hidratación, Robin/Neumann, clima, activación de vertidas ni el caso 3D real.
Neumann y Robin sí están implementados y verificados en `difusion_1d_bordes.py`.
La prueba uniforme usa bordes Dirichlet a la misma temperatura, no bordes aislados.
La activación por tiempo sí está implementada en el módulo de voxelización;
todavía no está conectada al solver térmico.

## Voxelización y propiedades — G00, G01, G02, G04

La revisión de las cuatro guías y el guion de demostración están en
`docs/ENTREGA_GUIAS.md`. Los horarios, material M1, temperatura de colocación y
protecciones son ejemplos didácticos, no datos calibrados ni un plan real aprobado.

```powershell
.\.venv\Scripts\python.exe voxelizar.py
.\.venv\Scripts\python.exe voxelizar.py --tiempo-h 24 --salida resultados/voxeles_24h
.\.venv\Scripts\python.exe voxelizar.py --tiempo-h 48 --salida resultados/voxeles_48h
```

Genera NPZ con centros, occupied, active, vertida_id, material_id, horarios y
temperaturas de colocación; CSV de error de volumen, metadatos JSON y un corte PNG.
`occupied` indica pertenencia geométrica; `active` indica hormigón ya colocado.
El volumen geométrico se compara con TODOS los voxeles ocupados, aunque aún no
se hayan colocado. No se debe confundir volumen total con volumen activo.

## THERMA — suelo efectivo (5A)

La subfase 5A añade contacto basal con un reservorio térmico y resistencia,
conservando el solver oficial, IFC, construcción por vertidas y escenarios.
Parámetros del ejemplo explícitamente didácticos; sin clima real y con S25 aún
NOT EVALUATED. Instrucciones, ecuaciones, resultados, sensibilidad y archivos:
[FASE5A_SUELO](docs/FASE5A_SUELO.md).

```powershell
.\.venv\Scripts\python.exe construir_panel.py
.\.venv\Scripts\python.exe servidor_therma.py --port 8767
```

Abrir http://127.0.0.1:8767/panel_termico.html. Elegir secuencia constructiva,
activar **05A Environment & Weather → Contacto basal con suelo efectivo** y
ejecutar. Caso sin navegador: `.\.venv\Scripts\python.exe demo_suelo.py`.

## Ecuaciones de borde en vivo

En el laboratorio, abrir **03 Condiciones de borde → Ver ecuación en vivo**.
Dirichlet, Neumann, Robin y suelo efectivo muestran fórmulas, unidades y
sustituciones inmediatas. Los campos siguen requiriendo Python; las entradas
editadas marcan STALE. [Uso y verificación](docs/ECUACIONES_EN_VIVO.md).

## Meteorología real y resultados 3D (E11)

La [guía E11](docs/E11_CLIMA_Y_VTK.md) recorre los ocho pasos de la revisión:
snapshot real y metadata, gráfico del aire, BC Robin, corrida de 72 h y visor
PyVista con corte móvil/clipping, núcleo y exterior. Incluye evidencia VTK ya
generada en `docs/e11/evidencia/vtk/serie.pvd` y comandos para repetir el caso.

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-viz.txt
.\.venv\Scripts\python.exe ver_resultados_3d.py docs/e11/evidencia/vtk
```

## Verificación del proyecto

El panel permite seguir un **núcleo y un voxel exterior fijos**, usar **03B
Moldaje físico** y editar Δx/Δy/Δz en **Malla → Personalizada**. Se recalcula la
máscara IFC en Python. [Uso, ecuaciones y discrepancia de volumen pendiente](docs/NUCLEO_MOLDAJE_Y_MALLA.md).

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

Comprueban temperatura uniforme, error frente a solución exacta, principio del
máximo, refinamiento, estabilidad, tiempo final, grilla, cambio de nombre IFC,
clasificación geométrica, identidades, volumen y activación de voxeles.

## Entrega

Antes de entregar: completar integrantes, ensayar la edición IFC en Bonsai,
leer G00/G01/G02/G05 y comprobar que todos expliquen el código.
No hay informe adicional para E02. Canvas solicita URL de repositorio y SHA:

```powershell
git rev-parse HEAD
```

Repositorio: https://github.com/Santiago411323/Proyecto_2_MCOC . Los instaladores,
el entorno virtual y los resultados generados se excluyen mediante .gitignore.
# Defensa final F02: lotes y riesgo

Guía reproducible: [docs/DEFENSA_FINAL_F02.md](docs/DEFENSA_FINAL_F02.md).
Ejecutar `python ejecutar_lotes_defensa.py --sensibilidad` y luego
`python exportar_defensa.py --publicar docs/defensa/evidencia`.
Genera la tabla de seis planes y las 24 combinaciones FV/SS–forecast.
**S25 de la fundación no está validado: no se certifica probabilidad conjunta
ni se recomienda un plan óptimo.** Los desconocidos se conservan en la tabla.

Selector de resolución y evaluación geométrica S25: [docs/RESOLUCION_S25_IFC.md](docs/RESOLUCION_S25_IFC.md).
El panel permite 500/250/125/50/25 mm y pasos anisótropos, con guardas de recursos.
S25 se desplaza 0,025 m desde los triángulos IFC; la reconstrucción es experimental
y puede quedar parcial por falta de stencil. No hay refinamiento local AMR ni
actualización de probabilidades con una métrica no validada.

Auditoría final S25, diagnóstico por área, par crítico y límites de validez: [docs/VALIDACION_FINAL_S25.md](docs/VALIDACION_FINAL_S25.md).

Exploración constructiva, tablas y apertura de planes calculados: [docs/EXPLORACION_CONSTRUCTIVA_S25.md](docs/EXPLORACION_CONSTRUCTIVA_S25.md).

Panel organizado por tareas y guía de navegación: [docs/PANEL_ORDENADO.md](docs/PANEL_ORDENADO.md).


Edición de geometría y propiedades desde HTML: [docs/GEOMETRIA_EDITABLE_HTML.md](docs/GEOMETRIA_EDITABLE_HTML.md).

Catálogo de simulaciones, reproducción y primer experimento: [docs/SIMULACIONES_PASO_A_PASO.md](docs/SIMULACIONES_PASO_A_PASO.md).

Los campos volumétricos de las corridas y el catálogo local en `resultados/` se
conservan fuera de Git. Las configuraciones, métricas y evidencias compactas se
versionan en `docs/`; los comandos de las guías permiten regenerar los campos.

Comparación F02 integrada, gráficos y evidencia: [docs/comparacion_f02/README.md](docs/comparacion_f02/README.md).

## Monte Carlo en Slurm

[Generar muestras reproducibles, ejecutar el array y graficar la excedencia acumulada](hpc/README.md).

/* Presentación de evidencia Python existente: sin modelo físico ni probabilidades JS. */
(function(){'use strict';const $=id=>document.getElementById(id),E=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
let data=null,cohort=null,plan=null,detail=null,ticket=0,loading=false,pendingIce=false;
const fmt=(v,d=2)=>typeof v==='number'&&Number.isFinite(v)?v.toLocaleString('es-CL',{minimumFractionDigits:d,maximumFractionDigits:d}):'NO EVALUADO',pct=v=>v===null||v===undefined?'INDETERMINADO':fmt(v*100),yes=v=>v===null||v===undefined?'INDETERMINADO':v?'1':'0',coord=v=>Array.isArray(v)?'('+v.map(x=>fmt(x,3)).join('; ')+') m':'no disponible';
const legacy=document.querySelector('#comparePage .plan-table-panel');legacy.hidden=true;
const decisionReport=$('decisionDefensa');
if(decisionReport){
  for(const span of decisionReport.querySelectorAll('[data-decision-run]')){
    const open=E('button','Ver campo 3D','quiet');
    open.type='button';
    open.title=span.dataset.decisionRun;
    open.onclick=async()=>{
      open.disabled=true;
      try{
        await window.therma.openArchived(span.dataset.decisionRun);
        window.ThermaNavigation.go('results');
      }catch(error){open.textContent='Campo local no disponible';open.title=error.message;}
      finally{open.disabled=false;}
    };
    span.replaceChildren(open);
  }
  const download=E('button','Guardar resumen para la defensa','secondary');
  download.type='button';
  download.onclick=()=>{
    const copy=decisionReport.cloneNode(true);
    for(const span of copy.querySelectorAll('[data-decision-run]'))span.textContent=span.dataset.decisionRun;
    copy.querySelector('button').remove();
    const html='<!doctype html><html lang="es"><meta charset="utf-8"><title>THERMA · Decisión F02</title><style>body{font:16px system-ui;margin:3vw}td,th,summary{padding:8px}.table-scroll{overflow:auto}</style>'+copy.outerHTML+'</html>';
    const url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));
    const link=E('a');link.href=url;link.download='THERMA-decision-F02.html';link.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  decisionReport.append(download);
}
async function api(url){const r=await fetch(url,{cache:'no-store'}),v=await r.json();if(!r.ok)throw Error(v.message||'No se pudo leer la evidencia Python.');return v;}
function table(headers,rows){const t=E('table',undefined,'plan-table'),head=E('tr');headers.forEach(h=>head.append(E('th',h)));const thead=E('thead');thead.append(head);t.append(thead);const body=E('tbody');for(const row of rows){const tr=E('tr');row.forEach(v=>{const td=E('td');typeof v==='object'&&v instanceof Node?td.append(v):td.textContent=v;tr.append(td);});body.append(tr);}t.append(body);return t;}
function box(canvas,height=260){const w=Math.max(280,Math.round(canvas.clientWidth||600)),dpr=Math.min(devicePixelRatio||1,2);canvas.width=w*dpr;canvas.height=height*dpr;canvas.style.height=height+'px';const g=canvas.getContext('2d');g.scale(dpr,dpr);g.font='11px Segoe UI';return {g,w,h:height};}
function axes(c,{end,low,high,xlabel='Tiempo [h]',ylabel='',threshold,height=260,top=40}){const b=box(c,height),{g,w,h}=b,L=48,R=w-18,T=top,B=h-42,X=t=>L+t/(end||1)*(R-L),Y=v=>B-(v-low)/(high-low||1)*(B-T);g.fillStyle='#9db7cb';g.fillText(ylabel,3,14);for(let j=0;j<=4;j++){const v=low+(high-low)*j/4;g.strokeStyle='#293e55';g.beginPath();g.moveTo(L,Y(v));g.lineTo(R,Y(v));g.stroke();g.fillText(fmt(v,0),4,Y(v)+4);}for(let j=0;j<=4;j++){const x=end*j/4;g.fillText(fmt(x,0),Math.min(R-12,X(x)),h-24);}g.fillText(xlabel,L,h-6);if(threshold!==undefined){g.strokeStyle='#f2a17b';g.setLineDash([5,4]);g.beginPath();g.moveTo(L,Y(threshold));g.lineTo(R,Y(threshold));g.stroke();g.setLineDash([]);g.fillStyle='#f2a17b';g.fillText('Límite '+threshold+(ylabel.includes('%')?' %':' °C'),Math.max(L,R-100),Y(threshold)-6);}return {...b,L,R,T,B,X,Y};}
function line(ctx,values,color,name,legend){const {g,X,Y}=ctx;g.save();g.beginPath();g.rect(ctx.L,ctx.T,ctx.R-ctx.L,ctx.B-ctx.T);g.clip();g.strokeStyle=color;g.lineWidth=1.8;g.beginPath();let open=false;for(const [t,v] of values){if(v===null||!Number.isFinite(v)||!Number.isFinite(t)){open=false;continue;}if(open)g.lineTo(X(t),Y(v));else g.moveTo(X(t),Y(v));open=true;}g.stroke();g.restore();g.fillStyle=color;g.fillText(name,50,21+legend*13);}
function message(ctx,text){ctx.g.fillStyle='#d7bc8e';ctx.g.font='12px Segoe UI';ctx.g.fillText(text,ctx.L+10,ctx.T+42);}
function download(name,content,mime){const url=URL.createObjectURL(new Blob([content],{type:mime})),a=E('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function csv(name,headers,rows){const escape=v=>'"'+String(v??'').replaceAll('"','""')+'"';download(name,'\ufeff'+[headers,...rows].map(r=>r.map(escape).join(',')).join('\r\n'),'text/csv;charset=utf-8');}
async function refresh(){
 if(loading)return;
 loading=true;
 $('f02Counts').textContent='Leyendo catálogos y métricas guardadas.';
 try{
  data=await api('/api/comparison-f02');
  const common=data.cohorts.filter(c=>c.id.startsWith('malla-comun-'));
  $('f02IcePlan').hidden=!common.length&&!data.cohorts.some(c=>c.id==='hielo-eps100-42');
  const select=$('f02Cohort'),prev=select.value,groups=new Map();
  select.replaceChildren();
  for(const c of [...common,...data.cohorts.filter(c=>!common.includes(c))]){
   const label=common.includes(c)?'F02 · malla común':c.historical?'Históricos / exploratorios':c.id.startsWith('local')?'Corridas propias':c.id.startsWith('malla')||c.id.startsWith('clima')?'Estudios de sensibilidad':'Otros conjuntos de planes';
   if(!groups.has(label)){
    const group=E('optgroup');group.label=label;select.append(group);groups.set(label,group);
   }
   const option=E('option',c.title);
   option.value=c.id;
   groups.get(label).append(option);
  }
  const defaultSet=common[0]||data.cohorts.find(c=>c.id.startsWith('cierre-'));
  select.value=data.cohorts.some(c=>c.id===prev)?prev:defaultSet?.id||data.cohorts[0]?.id;
  $('f02Counts').textContent=`Archivo completo: ${data.counts.cohorts} conjuntos y ${data.counts.scenario_rows} registros de escenarios, incluidas vistas parciales.`;
  selectCohort();
 }catch(e){$('f02Population').textContent=e.message+' Inicia el servidor actualizado.';}
 finally{
  loading=false;
  if(pendingIce&&!$('f02IcePlan').hidden){pendingIce=false;$('f02IcePlan').click();}
 }
}
function estimated(){return $('f02RiskMode').value==='estimated';}
function riskOf(p){return estimated()?(p.estimated_risk||{P_T:null,P_Delta:null,P_f:null,compliance:'INDETERMINADO'}):p.risk;}
function approximatePlan(v){
 const t=v.Tmax_C,d=v.Delta_estimate_C;
 if(!Number.isFinite(t)||!Number.isFinite(d))return 'SIN RESULTADO COMPLETO';
 if(t>70||d>20)return 'SUPERA ALGÚN LÍMITE · estimado';
 const complete=v.expected>0&&v.evaluated===v.expected&&v.runs.every(r=>r.status==='COMPLETED'&&r.horizon_captured&&r.numerical_checks&&r.coverage===1);
 return complete?'BAJO LOS LÍMITES · estimado':'PARCIAL · valores disponibles bajo límites';
}
function selectCohort(){cohort=data.cohorts.find(c=>c.id===$('f02Cohort').value);if(!cohort)return;const p=cohort.plans;
 $('f02DeltaRiskHeader').textContent=estimated()?'P_Δ aprox. [%]':'P_Δ formal [%]';
 $('f02JointRiskHeader').textContent=estimated()?'P_f conjunta aprox. [%]':'P_f conjunta formal [%]';
 $('f02ComplianceHeader').textContent=estimated()?'¿P_f ≤ 5 %? · aproximado':'¿Cumple? · formal';
 $('f02RiskModeNote').textContent=estimated()?'MODO APROXIMADO: probabilidades ponderadas usando S25 estimado, sólo en escenarios completos con cobertura de muestras. Un 0 % significa ninguna excedencia estimada en ese catálogo; no certifica ausencia de error numérico ni riesgo real de obra.':'MODO FORMAL: exige S25 validado. Los valores pendientes permanecen indeterminados aunque sus estimaciones estén bajo los límites.';
 $('f02Scope').textContent=cohort.title+' · '+cohort.scope+' Malla, horizonte, versión y familia separados. Cuatro referencias F02 primero; demás planes por duración. S25: ESTIMADO / NO VALIDADO. Los resultados del 13 de noviembre son históricos y no el caso final del día 19.';$('f02Plans').replaceChildren();const references=['continua','propuesto','rapido','lento'],rank=p=>references.includes(p.id)?references.indexOf(p.id):4;const ordered=[...p].sort((a,b)=>rank(a)-rank(b)||(a.D_h??Infinity)-(b.D_h??Infinity));const required={continua:'Una vertida',propuesto:'Propuesto',rapido:'Más rápido',lento:'Más lento'};
 for(const v of ordered){const tr=E('tr');const name=E('td',v.name);const mix=v.parameters?.preenfriamiento?.balance;if(mix)name.append(E('small',fmt(mix.dose_kg_m3)+' kg/m³ · '+fmt(mix.total_t)+' t de hielo','f02-reference'));if(required[v.id])name.append(E('small','Referencia: '+required[v.id],'f02-reference'));tr.append(name);[fmt(v.D_h),fmt(v.Tmax_C),fmt(v.Delta_estimate_C),approximatePlan(v),pct(riskOf(v).P_T),pct(riskOf(v).P_Delta),pct(riskOf(v).P_f),riskOf(v).compliance==='CUMPLE'?(estimated()?'SÍ · aproximado':'SÍ'):riskOf(v).compliance==='NO CUMPLE'?(estimated()?'NO · aproximado':'NO'):'INDETERMINADO'].forEach(text=>tr.append(E('td',text)));const td=E('td'),d=E('details'),s=E('summary',`Ver ${v.evaluated} corridas / ${v.expected||'?'} previstas`);d.append(s);const summary=E('p',`Tmax: ${fmt(v.Tmax_C)} °C · ΔT S25 estimado: ${fmt(v.Delta_estimate_C)} °C · pesos: ${v.risk.weights_valid?'catálogo suma 1; completadas '+fmt(v.risk.completed_weight_sum,2):'no fundamentados'} · faltantes: ${v.risk.missing.length} · ID: ${v.configuration_id}`,'hint');d.append(summary);d.append(E('p',JSON.stringify(v.parameters||{},null,2),'f02-params'));const rr=v.runs.map(r=>{const b=E('button','Graficar','quiet');b.type='button';b.onclick=()=>inspectPlan(v,r.uid);return [v.name,r.source_id,r.climate_id,r.weight??'NO ASIGNADO',fmt(r.Tmax_C),fmt(r.Delta_estimate_C)+' · estimado',yes(r.I_T),yes(estimated()?r.I_Delta_estimated:r.I_Delta),yes(estimated()?r.I_F_estimated:r.I_F),r.status+' · '+r.S25_validation+' · '+(r.shape?.join('×')||'?')+' · dt '+fmt(r.dt_s)+' s · Tmax a '+fmt(r.Tmax_time_h)+' h · ΔT a '+fmt(r.Delta_time_h)+' h · cobertura '+(r.coverage===null?'?':fmt(r.coverage*100)+' %')+' · config '+(r.configuration_hash||'no archivado'),b];});const wrap=E('div',undefined,'table-scroll');wrap.append(table(['Plan','Curva','Clima','Peso w','M_T [°C]','M_Δ estimado [°C]','I_T',estimated()?'I_Δ aprox.':'I_Δ formal',estimated()?'I_F aprox.':'I_F formal','Estado / malla / paso','Corrida'],rr));d.append(wrap);const toggle=E('button',v.evaluated+' escenarios','quiet');toggle.type='button';toggle.setAttribute('aria-label','Ver escenarios de '+v.name);toggle.setAttribute('aria-expanded','false');const extra=E('tr'),extraCell=E('td');extra.hidden=true;extraCell.colSpan=10;d.open=true;extraCell.append(d);extra.append(extraCell);toggle.onclick=()=>{extra.hidden=!extra.hidden;toggle.setAttribute('aria-expanded',String(!extra.hidden));d.open=true;};td.append(toggle);tr.append(td);$('f02Plans').append(tr,extra);}
 for(const [id,name] of Object.entries(required)){if(cohort.id.startsWith('hielo-eps100-42')||p.some(v=>v.id===id))continue;const tr=E('tr',undefined,'f02-missing');tr.append(E('td',name));const td=E('td','PENDIENTE DE SIMULACIÓN EN ESTE CONJUNTO');td.colSpan=8;tr.append(td);const action=E('button','Consultar plan existente','quiet');action.type='button';const definition=(cohort.pending_configurations||[]).find(p=>p.id===id),other=data.cohorts.find(c=>c.plans.some(v=>v.id===id));action.disabled=!definition&&!other;if(definition)action.textContent='Preparar '+name+' en 02';action.onclick=async()=>{if(definition){try{const prepared=await api('/api/comparison-f02/prepare/'+cohort.id+'/'+id);window.therma.setConfig(prepared.config);window.ThermaNavigation.go('configure');$('status').textContent=prepared.note+' Pulsa Ejecutar simulación.';}catch(e){$('f02Counts').textContent=e.message;}}else{$('f02Cohort').value=other.id;selectCohort();choose(id);}};const end=E('td');end.append(action);tr.append(end);$('f02Plans').append(tr);}
 const representative=decision(p);
 $('f02PlanSelect').replaceChildren();for(const v of ordered){const o=E('option',v.name+' · D '+fmt(v.D_h)+' h');o.value=v.id;$('f02PlanSelect').append(o);}choose(representative?.id||p.find(v=>v.id==='propuesto')?.id||p[0]?.id);drawRisk();}
function drawRisk(){if(!cohort)return;const plans=cohort.plans,end=Math.max(1,...plans.map(p=>p.D_h||0))*1.05,c=axes($('f02Risk'),{end,low:0,high:100,xlabel:'Duración física D [h]',ylabel:estimated()?'P_f APROXIMADA [%]':'P_f formal [%]',threshold:5});const known=plans.filter(p=>riskOf(p).P_f!==null&&p.D_h!==null);for(const p of known){c.g.fillStyle='#70d8c8';c.g.beginPath();c.g.arc(c.X(p.D_h),c.Y(riskOf(p).P_f*100),4,0,Math.PI*2);c.g.fill();}if(!known.length)message(c,estimated()?'Faltan escenarios, horizonte o cobertura · sin puntos ficticios':'PENDIENTE DE VALIDACIÓN · sin puntos ficticios');$('f02RiskNote').textContent=known.length?known.length+(estimated()?' planes con riesgo conjunto APROXIMADO; no validación formal.':' planes con riesgo conjunto evaluable en este conjunto.'):(estimated()?'P_f aproximada incompleta: revisa escenarios faltantes, horizonte, controles numéricos y cobertura S25.':'P_f formal indeterminada: requiere validación S25. No se representa como cero.');const d=axes($('f02Estimate'),{end,low:0,high:60,xlabel:'Duración física D [h]',ylabel:'ΔT S25 ESTIMADO [°C]',threshold:20});for(const p of plans){if(p.D_h===null||p.Delta_estimate_C===null)continue;d.g.fillStyle=p.id===plan?.id?'#f2af79':'#70d8c8';d.g.beginPath();d.g.arc(d.X(p.D_h),d.Y(p.Delta_estimate_C),4,0,Math.PI*2);d.g.fill();}}
function choose(id,uid){plan=cohort.plans.find(p=>p.id===id);if(!plan)return;scenarioRows();$('f02PlanSelect').value=id;$('f02RunSelect').replaceChildren();for(const r of plan.runs){const o=E('option',r.source_id+' · '+r.climate_id+' · '+r.status);o.value=r.uid;$('f02RunSelect').append(o);}$('f02RunSelect').value=uid||plan.runs.find(r=>r.source_id.includes('M4_SS'))?.uid||plan.runs[0]?.uid;selectRun();}
async function selectRun(){const uid=$('f02RunSelect').value;if(!uid)return;const id=++ticket;detail=null;$('f02RunIdentity').textContent='Nueva selección: '+plan.name+' · '+$('f02RunSelect').selectedOptions[0].textContent;$('f02Maxima').textContent='Leyendo los máximos de esta selección…';$('f02FieldState').textContent='Comprobando si existe el campo de esta corrida.';for(const canvas of [$('f02Temperatures'),$('f02Delta')]){const b=box(canvas);b.g.fillStyle='#b6ccdc';b.g.fillText('Cargando la selección; no se muestra otro escenario.',15,60);}$('f02EvidenceStatus').textContent='Leyendo historias y procedencia de esta corrida; no se recalcula.';$('f02Workspace').disabled=true;$('f02Reproduce').disabled=true;try{const d=await api('/api/comparison-f02/'+uid);if(id!==ticket)return;detail=d;const r=d.run,p=d.plan,c=d.config;$('f02RunIdentity').textContent=`${p.name} · ${r.source_id} · ${r.climate_id} · n=${r.shape?.join('×')||'?'} · dt=${fmt(r.dt_s)} s · horizonte ${fmt(r.days,0)} días · ID ${r.simulation_id||'no publicado'} · código ${r.engine||'no documentado'}`;const caption=p.name+' · '+r.source_id+' · '+r.climate_id+' · '+r.shape?.join('×')+' · '+r.days+' días';for(const id of ['f02ScheduleIdentity','f02TemperatureIdentity','f02DeltaIdentity'])$(id).textContent=caption;
 $('f02EvidenceStatus').textContent=`Estado ${r.status} · S25 ${r.S25_validation} · cobertura aire ${r.coverage===null?'no documentada':fmt(100*r.coverage)+' %'} · pesos ${plan.risk.weights_valid?'fijados en catálogo':'sin interpretación probabilística'}.`;
 $('f02Parameters').textContent=JSON.stringify({configuration_hash:r.configuration_hash,code:r.engine,start_utc:c?.weather?.start_utc,material:c?{k:c.k,rho:c.rho,cp:c.cp}:null,construction:c?.construction?{model:c.construction.model,source:c.construction.parameter_source,pours:c.construction.pours}:null,formwork:c?.formwork,faces:c?.faces,environment:c?.environment,physical_duration_h:p.D_h,rate_m3_h:p.rate_m3_h,thermal_approximation:p.thermal_approximation},null,2);
 $('f02Operations').replaceChildren(table(['Vertida','Volumen [m³]','Inicio físico [h]','Fin físico [h]','Activación térmica [h]'],p.operations.map(o=>[o.id,fmt(o.volume_m3),fmt(o.start_h),fmt(o.end_h),fmt(c?.construction?.pours.find(v=>v.id===o.id)?.start_h)])));
 $('f02Workspace').disabled=!d.fields_available;$('f02Reproduce').disabled=!d.config_available;$('f02FieldState').textContent=d.fields_available?'Campo 3D disponible. Se abrirá exactamente esta corrida con escala fija y corte.':d.run.partial_horizon?'Vista parcial de 14 días de una corrida de 42: selecciona el conjunto de 42 días para abrir su campo completo. No se presenta el máximo de 42 días como si ocurriera en 14.':'CAMPO 3D NO DISPONIBLE. Los resúmenes se conservan. Prepara su configuración en 02 y ejecuta Python si deseas reproducirla.';
 const pair=d.critical_pair,pk=d.peak_S25,hot=pair?.hot?.xyz_m||r.hot_xyz||pk?.hot_xyz_m,cold=pair?.cold?.xyz_m||r.cold_xyz||pk?.S25_xyz_m;
 $('f02Maxima').textContent=`Tmax: ${fmt(r.Tmax_C)} °C a ${fmt(r.Tmax_time_h)} h · XYZ ${coord(d.max_xyz)}. ΔT S25 máximo estimado: ${fmt(r.Delta_estimate_C)} °C a ${fmt(r.Delta_time_h)} h · punto caliente ${coord(hot)} · S25 ${coord(cold)}. `+(pair?`En el mismo instante: Tmax activa=${fmt(pair.hot.temperature_C)} °C, S25=${fmt(pair.cold.temperature_C)} °C; vertidas ${pair.hot.pour_id} / ${pair.cold.point_pour_id}; profundidad IFC 0,025 m.`:'Coordenadas/temperaturas del par no archivadas en este resumen; no se completan con otro resultado.');
 $('f02FixedPoints').textContent=d.fixed.map(s=>s.name+' · '+coord(s.position)+' · '+s.kind).join('\n')||'Sin historias de puntos fijos exportadas en esta corrida.';
 $('f02ArchivedFigure').hidden=!d.archive_figure;$('f02ArchivedFigure').open=!!d.archive_figure;if(d.archive_figure)$('f02ArchivedFigure').querySelector('img').src='/api/comparison-assets/'+d.archive_figure;
 $('f02Hour').max=r.days*24;drawEvidence();drawRisk();}catch(e){if(id===ticket)$('f02EvidenceStatus').textContent=e.message;}}
function schedule(){if(!detail)return;const pp=$('f02AllSchedules').checked?cohort.plans:[detail.plan],lines=pp.flatMap(p=>p.operations.map(o=>({p,o}))),height=Math.max(150,lines.length*26+80),end=Math.max(1,...cohort.plans.map(p=>p.D_h||0))*1.05;const {g,w}=box($('f02Schedule'),height),L=140,R=w-20,X=t=>L+t/end*(R-L);g.fillStyle='#94b6cb';g.fillText('Horas desde t0 · barras físicas / puntos de activación',10,18);if(!lines.length){g.fillText('Cronograma físico no declarado. D no se infiere de las activaciones.',10,55);return;}for(let j=0;j<=4;j++)g.fillText(fmt(end*j/4,1)+' h',X(end*j/4)-8,height-10);lines.forEach(({p,o},i)=>{const y=40+i*26;g.fillStyle='#a5bdce';g.fillText((pp.length>1?p.name.slice(0,16)+' · ':'')+'V'+o.id,5,y+11);g.fillStyle='#23384a';g.fillRect(L,y,R-L,15);g.fillStyle=['#6dd8c5','#dcba7a','#ba94d7'][(o.id-1)%3];g.fillRect(X(o.start_h),y,Math.max(1,X(o.end_h)-X(o.start_h)),15);const start=p.id===detail.plan.id?detail.config?.construction?.pours.find(v=>v.id===o.id)?.start_h:p.thermal_starts?.[String(o.id)];if(start!==undefined){g.fillStyle='#f0f7ff';g.beginPath();g.arc(X(start),y+7,3,0,Math.PI*2);g.fill();}g.fillStyle='#d2e2ee';g.fillText(fmt(o.start_h,1)+'–'+fmt(o.end_h,1),Math.min(R-65,X(o.end_h)+4),y+12);});}
function drawEvidence(){if(!detail)return;schedule();const r=detail.run,end=r.days*24,lo=Number($('f02ScaleLow').value),hi=Number($('f02ScaleHigh').value);if(!Number.isFinite(lo)||!Number.isFinite(hi)||hi<=lo){$('f02CurveNote').textContent='Escala inválida: máximo mayor que mínimo.';return;}const c=axes($('f02Temperatures'),{end,low:lo,high:hi,ylabel:'Temperatura [°C]',threshold:70,height:335,top:100}),h=detail.history;let legend=0;
 if(h.some(v=>v.Tmax_C!==null))line(c,h.map(v=>[v.time_s/3600,v.Tmax_C]),'#f0ae79','Tmax activa · envolvente móvil',legend++);
 if(h.some(v=>v.Tmin_S25_C!==null))line(c,h.map(v=>[v.time_s/3600,v.Tmin_S25_C]),'#62d7c7','Tmin S25 · envolvente móvil ESTIMADA',legend++);
 for(const s of detail.fixed){const color=s.name.includes('S25')?'#c49cea':s.name.includes('Interior')||s.name==='nucleo'?'#e8da89':'#87b7ed';line(c,s.values.map(v=>[v[0]/3600,v[1]]),color,s.name,legend++);}
 if(!h.length&&!detail.fixed.length)message(c,'Historia no archivada · sólo métricas resumidas');
 if(r.Tmax_time_h!==null&&r.Tmax_C!==null){c.g.strokeStyle='#efb286';c.g.setLineDash([2,3]);c.g.beginPath();c.g.moveTo(c.X(r.Tmax_time_h),c.T);c.g.lineTo(c.X(r.Tmax_time_h),c.B);c.g.stroke();c.g.setLineDash([]);c.g.fillStyle='#fff';c.g.beginPath();c.g.arc(c.X(r.Tmax_time_h),c.Y(r.Tmax_C),3,0,Math.PI*2);c.g.fill();}
 $('f02CurveNote').textContent=detail.curve_warning+' '+(!h.some(v=>v.Tmin_S25_C!==null)?'No hay serie S25 numérica disponible; no se sustituye por Tmin del primer voxel.':'');
 const d=axes($('f02Delta'),{end,low:0,high:60,ylabel:'ΔT S25 ESTIMADO [°C]',threshold:20,height:310});const valid=h.filter(v=>v.Delta_C!==null&&Number.isFinite(v.Delta_C));if(valid.length){line(d,valid.map(v=>[v.time_s/3600,v.Delta_C]),'#e9b774','ΔT(t) · simultáneo, NO VALIDADO',0);const peak=valid.reduce((a,b)=>a.Delta_C>b.Delta_C?a:b);d.g.fillStyle='#fff';d.g.beginPath();d.g.arc(d.X(peak.time_s/3600),d.Y(peak.Delta_C),4,0,Math.PI*2);d.g.fill();d.g.fillText(fmt(peak.Delta_C)+' °C · '+fmt(peak.time_s/3600)+' h',d.L+10,d.T+42);}else message(d,'Serie S25 no archivada · no se inventa curva');}
async function workspace(){if(!detail?.fields_available)return;const selected=detail,uid=detail.run.uid;$('f02FieldState').textContent='Cargando el campo real seleccionado…';try{await window.therma.openArchived(selected.run.simulation_id);if(detail?.run.uid!==uid)return;window.ThermaNavigation.go('results');$('scaleMode').value='fixed';$('scaleLow').value=$('f02ScaleLow').value;$('scaleHigh').value=$('f02ScaleHigh').value;$('scaleMode').dispatchEvent(new Event('change'));const r=window.therma.getResult(),which=$('f02Instant').value,time=which==='max'?selected.run.Tmax_time_h:which==='delta'?selected.run.Delta_time_h:Number($('f02Hour').value);if(time!==null&&Number.isFinite(time))window.therma.setFrame(ThermaViewData.nearest(r.frameTimes,time*3600));if(which==='delta'&&!$('showS25Critical').disabled)$('showS25Critical').click();else{const index=ThermaIntelligence.globalMaximum(r).index;if(which==='max'&&index>=0)window.therma3d?.investigate(index);else{$('viewerMode').value='xray';$('viewerMode').dispatchEvent(new Event('change'));}}$('viewerSection').scrollIntoView({block:'start',behavior:'smooth'});}catch(e){$('f02FieldState').textContent=e.message;}}
$('f02RiskMode').onchange=()=>{if(data)selectCohort();};$('f02Cohort').onchange=selectCohort;$('f02PlanSelect').onchange=()=>choose($('f02PlanSelect').value);$('f02RunSelect').onchange=selectRun;$('f02Refresh').onclick=refresh;$('f02AllSchedules').onchange=schedule;for(const id of ['f02ScaleLow','f02ScaleHigh'])$(id).oninput=drawEvidence;$('f02Workspace').onclick=workspace;
$('f02Reproduce').onclick=()=>{if(!detail?.config)return;const c=structuredClone(detail.config);if(detail.run.partial_horizon)c.days=detail.run.days;window.therma.setConfig(c);window.ThermaNavigation.go('configure');$('status').textContent='Configuración recuperada de la evidencia. Revisa los datos y pulsa Ejecutar simulación para reproducir; no se ejecutó automáticamente.';};
$('f02ExportPlans').onclick=()=>cohort&&csv('therma-tabla-planes.csv',['Plan','D [h]','Tmax [°C]','Delta S25 aproximado [°C]','Comparación aproximada 70/20 °C','P_T [%]',estimated()?'P_Δ aprox. [%]':'P_Δ formal [%]',estimated()?'P_f aprox. [%]':'P_f formal [%]',estimated()?'Bajo 5 % aproximado':'¿Cumple? formal','Conjunto','Alcance'],cohort.plans.map(p=>[p.name,p.D_h,p.Tmax_C,p.Delta_estimate_C,approximatePlan(p),pct(riskOf(p).P_T),pct(riskOf(p).P_Delta),pct(riskOf(p).P_f),riskOf(p).compliance,cohort.title,cohort.scope]));
$('f02ExportRuns').onclick=()=>cohort&&csv('therma-escenarios.csv',['Plan','Curva','Clima','Peso w','M_T [°C]','M_Δ estimado [°C]','I_T',estimated()?'I_Δ aprox.':'I_Δ formal',estimated()?'I_F aprox.':'I_F formal','Estado','Malla','Horizonte [d]','Versión','ID'],cohort.plans.flatMap(p=>p.runs.map(r=>[p.name,r.source_id,r.climate_id,r.weight,r.Tmax_C,r.Delta_estimate_C,yes(r.I_T),yes(estimated()?r.I_Delta_estimated:r.I_Delta),yes(estimated()?r.I_F_estimated:r.I_F),r.status,r.shape?.join('×'),r.days,r.engine,r.simulation_id])));
new ResizeObserver(()=>{if(!$('comparePage').hidden){drawRisk();drawEvidence();drawScenarioPeaks();}}).observe($('f02Comparison'));
$('f02IcePlan').onclick=()=>{
 const available=data.cohorts;
 const target=available.find(c=>c.id.startsWith('malla-comun-'))||
  available.find(c=>c.id==='hielo-eps100-42_estudiada')||available.find(c=>c.id==='hielo-eps100-42');
 if(!target)return;
 $('f02Cohort').value=target.id;selectCohort();changeView('plans');
};
/*__F02_SUMMARY__*/
async function openRun(cohortId,planId,uid){
 window.ThermaNavigation.go('compare');
 $('f02Analysis').open=true;
 changeView('runs');
 const drawer=$('f02RunDrawer');
 drawer.open=true;
 drawer.scrollIntoView({block:'start'});
 if(!data?.cohorts.some(c=>c.id===cohortId))await refresh();
 if(!data?.cohorts.some(c=>c.id===cohortId)){
  $('f02EvidenceStatus').textContent='Este estudio todavía no se ha cargado. Usa Actualizar catálogo y vuelve a abrir la fila.';
  return;
 }
 $('f02Cohort').value=cohortId;
 selectCohort();
 choose(planId,uid);
}
window.ThermaF02={refresh,openRun,openIce:()=>{$('f02Analysis').open=true;pendingIce=true;if(data&&!$('f02IcePlan').hidden){pendingIce=false;$('f02IcePlan').click();}}};refresh();
})();

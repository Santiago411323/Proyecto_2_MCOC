/* El visor lee la misma configuración que envía THERMA a Python. */
(function(){'use strict';const $=id=>document.getElementById(id),M=window.ThermaBoundaryMath;let selected=-1,frame=0,result=null;
const fmt=v=>typeof v==='number'&&Number.isFinite(v)?Number(v.toPrecision(7)).toLocaleString('es-CL',{maximumFractionDigits:7}):v??'incógnita';
function math(id,text){const wrap=$(id),ns='http://www.w3.org/1998/Math/MathML',node=(tag,value)=>{const e=document.createElementNS(ns,tag);if(value!==undefined)e.textContent=value;return e;};wrap.replaceChildren();for(const line of text.split('\n')){const m=node('math');m.setAttribute('display','block');for(const token of line.split(/([A-Za-z]+_[A-Za-zó]+|q″salida|q″impuesto|R″total)/g)){const parts=token.split('_');if(parts.length===2){const sub=node('msub');sub.append(node('mi',parts[0]),node('mtext',parts[1]));m.append(sub);}else if(/^[qR]″/.test(token)){const sub=node('msubsup');sub.append(node('mi',token[0]),node('mtext',token.slice(2)),node('mo','″'));m.append(sub);}else m.append(node('mtext',token));}wrap.append(m);}}
function update(){if(!window.therma)return;try{const current=window.therma.getConfig(),source=$('equationSource').value,face=Number($('equationFace').value);const next=window.therma.getResult();if(next!==result)selected=-1;result=next;frame=window.therma.state.frame;const cfg=source==='stored'?result?.config:current;if(!cfg)throw Error('No hay una corrida disponible.');
 for(const option of $('equationFace').options)option.disabled=Number(option.value)>=2*cfg.dim;
 if(face>=2*cfg.dim){$('equationFace').value='0';return update();}
 const config=JSON.parse(JSON.stringify(cfg));let classification=null,T=null,context=source==='stored'?'Configuración efectiva de la última simulación.':'Entradas actuales: vista previa algebraica, no nueva solución PDE.';
 if(source==='draft'){config.faces[face]={type:$('globalType').value,temp:Number($('globalTemp').value),h:Number($('globalH').value),R:Number($('globalR').value),flux:Number($('globalFlux').value)};delete config.environment;context='Borrador global: estos valores NO se envían como fronteras hasta pulsar «Aplicar a las caras activas». La base de suelo no se reemplaza.';}
 if(selected>=0&&result&&source!=='draft'){
 if(!M.compatible(config,result))context+=' Selección no utilizable: cambió la grilla, máscara u origen. Vuelve a ejecutar y seleccionar.';
 else{classification=M.faceClass(result,selected,face,frame);if(classification==='soil'&&!config.environment?.soil)classification='air';if(classification==='air'&&config.environment?.soil&&face===4){const ijk=window.ThermaViewData.ijk(selected,result.n);if(ijk[2]===0)classification='soil';}
 if($('equationUseCell').checked&&classification!=='inactive')T=result.fields[frame][selected];context+=` Celda ${selected} · cara ${M.names[face]} · ${classification}; actividad e interfaces según la máscara del snapshot, no un cronograma editado sin resolver.`;
 }}
 if(result)context+=` Referencia: ${result.simulationId||result.label||'verificación JS'} · ${(result.frameTimes[frame]/3600).toFixed(5)} h. ${$('executionState').textContent}.`;
 if(T!==null)context+=' T_celda tomada de ese snapshot. Con entradas cambiadas, el flujo es sólo una reevaluación algebraica usando una temperatura anterior.';
 const time=source==='stored'&&result?result.frameTimes[frame]:0;
 if(config.formwork?.remove_at_h!==undefined&&time>=config.formwork.remove_at_h*3600){delete config.formwork;context+=' Moldaje retirado en este instante.';}
 if(config.weather&&config.faces[face].type==='R'&&classification!=='soil'){
 const w=config.weather,epoch=Date.parse(w.start_utc)+time*1000;let j=-1;
 for(let i=0;i<w.time_utc.length;i++){if(Date.parse(w.time_utc[i])<=epoch)j=i;else break;}
 if(j<0||epoch>Date.parse(w.time_utc.at(-1)))throw Error('Instante fuera de cobertura meteorológica.');
 config.faces[face].temp=w.temperature_C[j];context+=' Aire horario de la serie cargada; h constante.';
 }
 const view=M.describe(config,face,{cellTemperature:T,classification});math('equationGeneral',view.formula);math('equationSubstitution',view.substitution);$('equationValues').replaceChildren();for(const row of view.rows){const tr=document.createElement('tr');for(const value of row){const td=document.createElement('td');td.textContent=fmt(value);tr.append(td);}$('equationValues').append(tr);}
 $('equationResult').textContent=view.flux===null?'Sin flujo numérico disponible':`${view.type==='N'?'Flujo impuesto':'Vista previa algebraica'}: q″salida = ${fmt(view.flux)} W/m²`;
 $('equationExplanation').textContent=view.explanation;$('equationFlow').textContent=view.flux===null?'Hormigón │ frontera │ entorno · signo exterior positivo':view.flux>0?'HORMIGÓN → ENTORNO · sale calor':view.flux<0?'HORMIGÓN ← ENTORNO · entra calor':'HORMIGÓN │ ENTORNO · flujo cero';$('equationContext').textContent=context;
 $('equationLayers').hidden=view.type!=='R'||source==='stored';
 }catch(e){$('equationContext').textContent='Revisa entradas: '+e.message;$('equationGeneral').replaceChildren();$('equationSubstitution').replaceChildren();$('equationValues').replaceChildren();$('equationResult').textContent='NOT EVALUATED';$('equationExplanation').textContent='';$('equationFlow').textContent='';}}
function layerChange(){try{const parts=[{enabled:$('eqFormOn').checked,e:Number($('eqFormE').value),k:Number($('eqFormK').value)},{enabled:$('eqInsOn').checked,e:Number($('eqInsE').value),k:Number($('eqInsK').value)}],R=M.layers(parts),source=$('equationSource').value,face=Number($('equationFace').value),target=source==='draft'?$('globalR'):$('fr'+face);if(source==='stored'||target.disabled)throw Error('Selecciona una cara de aire de las entradas actuales.');target.value=String(R);target.dispatchEvent(new Event('input',{bubbles:true}));$('equationLayerSum').textContent=`Rprotección = ${parts.map(p=>p.enabled?`${p.e}/${p.k}`:'0').join(' + ')} = ${fmt(R)} m²·K/W; enviado al único campo R.`;update();}catch(e){$('equationLayerSum').textContent=e.message;}}
for(const id of ['equationSource','equationFace','equationUseCell'])$(id).addEventListener('input',update);
for(const id of ['eqFormOn','eqFormE','eqFormK','eqInsOn','eqInsE','eqInsK'])$(id).addEventListener('input',layerChange);
$('equationClearCell').onclick=()=>{selected=-1;update();};
$('openEquation').onclick=()=>{$('equationViewer').open=true;$('equationViewer').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});};
$('controls').addEventListener('focusin',e=>{if(e.target.id.startsWith('global'))$('equationSource').value='draft';else{const m=e.target.id.match(/^f[tbqhr](\d)$/);if(m){$('equationSource').value='current';$('equationFace').value=m[1];}}update();});
window.addEventListener('therma:inputs',update);window.addEventListener('therma:frame',update);window.addEventListener('therma:selection',()=>{selected=window.therma3d?.getSelected()??-1;update();});
window.addEventListener('therma:boundary-selection',e=>{selected=e.detail.index;$('equationFace').value=e.detail.face;$('equationSource').value='current';update();});
new MutationObserver(update).observe($('executionState'),{childList:true,subtree:true,characterData:true});
window.ThermaEquations={update};update();
})();

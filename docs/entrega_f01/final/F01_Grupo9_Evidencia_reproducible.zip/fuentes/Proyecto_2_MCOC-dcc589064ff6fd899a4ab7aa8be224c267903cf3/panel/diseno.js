/* Presentación y guía: no modifica configuraciones ni resultados físicos. */
(function(){'use strict';const $=id=>document.getElementById(id);
const hero=document.querySelector('#foundationPage>.hero');
hero.className='studio-hero';hero.innerHTML=`<div><div class="studio-overline">THERMA LAB / HORMIGÓN MASIVO</div><h1>Cada vertida,<br><em>a la temperatura correcta.</em></h1><p>Explora tu fundación, diseña el preenfriamiento con hielo y compara cómo la aislación cambia su respuesta térmica.</p><div class="studio-actions"><button class="primary" id="studioCompare">Comparar planes de hielo <span aria-hidden="true">↗</span></button><button class="secondary" id="studioConfigure">Configurar mi plan →</button></div></div><aside class="criteria-card" aria-label="Límites del proyecto"><div class="criteria-label">Dos límites. Una decisión informada.</div><div class="criteria-grid"><div><strong>70<small> °C</small></strong><span>Temperatura máxima<br>del hormigón activo</span></div><div><strong>20<small> °C</small></strong><span>Diferencial máximo<br>interior / S25</span></div></div><p class="criteria-foot">Criterios del proyecto, no resultados de una corrida.<br>La evaluación S25 conserva su carácter estimado.</p></aside>`;
const title=document.createElement('div');title.className='journey-title';title.innerHTML='<h2>Tu siguiente paso</h2><span>Del modelo a una decisión que puedes explicar.</span>';
const cards=document.createElement('section');cards.className='journey-grid';cards.setAttribute('aria-label','Accesos al estudio');
const icons=['<path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9M9 5l3 3 3-3M9 19l3-3 3 3"/>','<path d="M3 8l9-5 9 5-9 5-9-5zm0 5l9 5 9-5M3 18l9 5 9-5"/>','<path d="M4 19V5m0 14h17M8 15l4-5 4 2 5-8"/>'];
const entries=[['Hielo, con un objetivo','Calcula la dosis o prueba una temperatura de colocación.','ice'],['Explora el campo térmico','Abre una corrida, recorre el tiempo y mira el interior.','results'],['Compara y decide','Contrasta temperaturas, diferenciales y duración de los planes.','compare']];
entries.forEach(([name,text,target],i)=>{const b=document.createElement('button');b.type='button';b.className='journey-card';b.innerHTML=`<span class="journey-icon" aria-hidden="true"><svg viewBox="0 0 24 26">${icons[i]}</svg></span><span class="journey-arrow" aria-hidden="true">↗</span><strong>${name}</strong><p>${text}</p>`;b.onclick=()=>navigate(target);cards.append(b);});
const entry=document.querySelector('#foundationPage>.sim-entry');if(entry)document.querySelector('#foundationPage>.foundation-layout').after(entry);
const scope=document.querySelector('#foundationPage>.foundation-scope');if(scope){scope.before(title,cards);const details=document.createElement('details');details.className='panel workflow-details';details.innerHTML='<summary>Qué representa este modelo</summary>';scope.before(details);details.append(scope);}
function navigate(target){window.ThermaNavigation.go(target==='ice'?'configure':target);if(target==='ice'){selectMode('ice');$('iceForm').open=true;}if(target==='compare')window.ThermaF02?.openIce();}
$('studioCompare').onclick=()=>navigate('compare');$('studioConfigure').onclick=()=>navigate('configure');
const configure=$('configurePage'),heading=configure.querySelector('.page-heading'),ice=$('iceForm');
const modes=document.createElement('div');modes.className='config-mode-switch';modes.setAttribute('role','group');modes.setAttribute('aria-label','Tipo de configuración');
const complete=document.createElement('div');complete.id='completePlanFields';for(const id of ['configActions','configEquationSlot'])if($(id))complete.append($(id));
const layout=configure.querySelector('.config-layout');complete.insertBefore(layout,complete.lastElementChild);heading.after(modes,ice,complete);
for(const [key,label] of [['complete','Plan completo · hielo y aislación'],['ice','Ensayo rápido · dosis de hielo']]){const b=document.createElement('button');b.type='button';b.dataset.configMode=key;b.textContent=label;b.onclick=()=>selectMode(key);modes.append(b);}
function selectMode(key){ice.hidden=key!=='ice';complete.hidden=key==='ice';for(const b of modes.children)b.setAttribute('aria-pressed',String(b.dataset.configMode===key));if(key==='ice')ice.open=true;window.dispatchEvent(new Event('resize'));}
selectMode('complete');
const meshCard=document.createElement('section');
meshCard.className='panel';
meshCard.innerHTML='<h3>Malla estudiada para los planes con hielo</h3><p><strong>96 × 96 × 54</strong> · 225.936 voxeles de hormigón en el IFC de referencia.</p><p>Con M4_SS, al refinar a 100 × 100 × 60, el ΔT S25 estimado cambió 0,032 °C para colocación a 8 °C y 0,049 °C a 12 °C. Ambos cambios quedaron bajo la tolerancia del estudio de 0,10 °C.</p><button class="secondary" type="button">Aplicar esta malla al plan actual</button><p class="hint" role="status"></p>';
complete.prepend(meshCard);
const meshButton=meshCard.querySelector('button');
const meshStatus=meshCard.querySelector('[role=status]');
function showPlanMesh(){
  meshCard.hidden=$('geometry').value!=='foundation';
  const shape=['nx','ny','nz'].map(id=>Number($(id).value));
  const selected=shape.join(',')==='96,96,54';
  meshButton.disabled=selected;
  meshStatus.textContent='Malla configurada: '+shape.join(' × ')+(selected?' · Ejecuta Python para calcular el plan con esta malla.':'');
}
meshButton.onclick=()=>{
  const preset=$('resolutionPreset');
  preset.value='study96';
  preset.dispatchEvent(new Event('change',{bubbles:true}));
  showPlanMesh();
};
window.addEventListener('therma:inputs',showPlanMesh);
showPlanMesh();
const boundaries=$('globalR').closest('details');boundaries.querySelector('summary').textContent='3. Aislación exterior y condiciones de borde';$('formworkOptions').after(boundaries);
const insulation=document.createElement('div');insulation.className='insulation-helper';insulation.innerHTML='<div class="eyebrow">AISLACIÓN EN LAS CARAS AL AIRE</div><h3>Del espesor a la protección térmica.</h3><p class="hint">Calcula R = espesor / conductividad y aplícala a los laterales y la parte superior. El moldaje se suma por separado; la base mantiene su contacto con el suelo.</p><div class="field-grid"><label>Espesor de aislación [mm]<input type="number" id="studioInsMm" value="100" min="0" step="1"></label><label>Conductividad [W/(m·K)]<input type="number" id="studioInsK" value="0.038" min="0.001" step="0.001"></label></div><button type="button" class="secondary" id="studioApplyIns">Aplicar aislación a las caras al aire</button><p class="hint" id="studioInsStatus" role="status">Reemplaza la R adicional de x±, y± y z+. Mantiene los otros parámetros de borde.</p>';
boundaries.querySelector('.detail-body').prepend(insulation);
$('studioApplyIns').onclick=()=>{const mm=Number($('studioInsMm').value),k=Number($('studioInsK').value);if(!Number.isFinite(mm)||!Number.isFinite(k)||mm<0||k<=0){$('studioInsStatus').textContent='Revisa el espesor (≥0) y la conductividad (>0).';return;}const R=mm/1000/k;for(const i of [0,1,2,3,5])$('fr'+i).value=R;$('fr0').dispatchEvent(new Event('input',{bubbles:true}));$('studioInsStatus').textContent=`R adicional = ${R.toLocaleString('es-CL',{maximumFractionDigits:4})} m²·K/W aplicada a cinco orientaciones. Ejecuta Python para calcular el efecto.`;};
$('environmentOptions').querySelector('summary').textContent='4. Contacto con el suelo';$('weatherOptions').querySelector('summary').textContent='5. Clima y temperatura ambiente';$('resolutionOptions').querySelector('summary').textContent='6. Malla y calidad numérica';
const originalGo=window.ThermaNavigation.go;window.ThermaNavigation.go=function(next){if(next==='configure')selectMode('complete');return originalGo(next);};
const guide=document.createElement('dialog');guide.className='guide-dialog';guide.setAttribute('aria-labelledby','studioGuideTitle');guide.innerHTML='<button type="button" class="guide-close" aria-label="Cerrar guía">×</button><div class="eyebrow">UN RECORRIDO DE CUATRO PASOS</div><h2 id="studioGuideTitle">De la fundación al resultado.</h2><ol><li><strong>Fundación.</strong> Revisa las tres piezas IFC y los datos del caso.</li><li><strong>Configurar.</strong> Ajusta colocación, aislación y ambiente. El ensayo de hielo calcula la dosis por separado.</li><li><strong>Simulaciones.</strong> Abre una corrida guardada o ejecuta tus cambios. Usa el tiempo y los cortes para explorar.</li><li><strong>Comparar.</strong> Evalúa Tmax, ΔT y duración bajo el mismo escenario.</li></ol><p>Los límites son 70 °C y 20 °C. Un diferencial S25 estimado bajo el límite no equivale a una validación formal.</p><button type="button" class="primary" id="guideDone">Entendido, explorar →</button>';document.body.append(guide);
guide.querySelector('.guide-close').onclick=() => guide.close();$('guideDone').onclick=()=>guide.close();guide.addEventListener('click',e=>{if(e.target===guide)guide.close();});$('helpBtn').textContent='Guía rápida';$('helpBtn').onclick=()=>guide.showModal();
const footer=document.createElement('div');footer.className='studio-footer';footer.innerHTML='<strong>THERMA LAB · GRUPO 09</strong><span>HIELO + AISLACIÓN / FUNDACIÓN IFC</span><a href="https://github.com/Santiago411323/Proyecto_2_MCOC" target="_blank" rel="noopener">Repositorio del proyecto ↗</a>';document.body.append(footer);
$('simulationGuide').open=false;
const oldPlans=document.querySelector('#comparePage>.plan-table-panel');if(oldPlans&&!oldPlans.hidden){const d=document.createElement('details');d.className='panel workflow-details';d.innerHTML='<summary>Antecedentes · exploración inicial del 13 de noviembre</summary>';oldPlans.before(d);d.append(oldPlans);}
})();

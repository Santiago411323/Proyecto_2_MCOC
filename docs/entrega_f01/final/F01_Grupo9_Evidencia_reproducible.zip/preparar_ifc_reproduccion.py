"""Normaliza solo finales de línea para recuperar el hash IFC del catálogo.
No omite el control de integridad: el resultado debe coincidir con el hash esperado.
"""
from pathlib import Path
import os,sys,hashlib,json
base=Path(__file__).parent
repo=Path(os.environ.get('THERMA_REPO',base/'fuentes/Proyecto_2_MCOC-dcc589064ff6fd899a4ab7aa8be224c267903cf3'))
path=repo/'modelo_e02.ifc';data=path.read_bytes();expected='40afdf7f2d87370523895e381247ed6892d38142ff99cb806778677042f316c4'
if hashlib.sha256(data).hexdigest()!=expected:
    normalized=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    if hashlib.sha256(normalized).hexdigest()!=expected:raise ValueError('El IFC difiere en contenido: no se normaliza ni se ignora su hash.')
    path.write_bytes(normalized)
print('IFC verificado:',expected)
